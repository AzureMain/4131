  //
  // document.body.setAttribute( "style", "-moz-transform: rotate(-180deg);");
  // document.body.setAttribute( "style", "-webkit-transform: rotate(-180deg);");
  // document.body.setAttribute( "style", "-o-transform: rotate(-180deg);");
// $("body").css({rotate: "30deg"});
//
// //
// document.getElementById("all").style.transformOrigin = "20% 30%"
/*jslint browser:true */
document.getElementById("all").style.setProperty("-webkit-transform", "rotate(180deg)", null);
document.getElementById("all").style.setProperty("-moz-transform", "rotate(180deg)", null);
document.getElementById("all").style.setProperty("-o-transform", "rotate(-180deg)", null);
// document.getElementById("all").style.color = "red";
document.getElementById("2").style.setProperty("-webkit-transform", "rotate(-180deg)", null);
document.getElementById("2").style.right = "60%";
document.getElementById("1").style.setProperty("-webkit-transform", "rotate(-180deg)", null);
document.getElementById("1").style.right = "78%";
document.getElementById("3").style.setProperty("-webkit-transform", "rotate(-180deg)", null);
document.getElementById("3").style.right = "67%";
document.getElementById("4").style.setProperty("-webkit-transform", "rotate(-180deg)", null);
document.getElementById("4").style.right = "68%";
document.getElementById("5").style.setProperty("-webkit-transform", "rotate(-180deg)", null);
document.getElementById("5").style.right = "73%";
document.getElementById("6").style.setProperty("-webkit-transform", "rotate(-180deg)", null);
document.getElementById("6").style.right = "65%";
document.getElementById("7").style.setProperty("-webkit-transform", "rotate(-180deg)", null);
document.getElementById("7").style.right = "70%";
document.getElementById("8").style.setProperty("-webkit-transform", "rotate(-180deg)", null);
document.getElementById("8").style.left = "-2px";
// document.getElementById("all").style.setProperty("-moz-transform", "rotate(180deg)", null);
// document.getElementById("all").style.setProperty("-o-transform", "rotate(-180deg)", null);
// document.getElementById("all").style.setProperty("-webkit-transform", "rotate(-180deg)", null);
// document.body.style.position = "relative";
// document.getElementById("all").style.t = "absolute";
// // document.body.style.backgroundColor = "lightyellow";
